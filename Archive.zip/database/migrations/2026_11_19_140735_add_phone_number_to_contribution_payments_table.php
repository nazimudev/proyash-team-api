<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('contribution_payments', function (Blueprint $table) {
            $table->string('phone_number', 20)
                ->nullable()
                ->after('transaction_id');
        });
    }

    public function down(): void
    {
        Schema::table('contribution_payments', function (Blueprint $table) {
            $table->dropColumn('phone_number');
        });
    }
};
